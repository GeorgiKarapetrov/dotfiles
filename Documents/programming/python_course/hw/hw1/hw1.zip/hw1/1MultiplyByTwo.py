while True:
    s = input("Enter a number: ")
    i = float(s)
    
    #check if number
    #this doesn't work
    #the probram brakes on trying to convert string to float if it is not possible
    if  type(i)  is not float:
        print("This is not a number. Try again.")
        continue
    
    #check if int
    if  i - i // 1 == 0:
        print(s, "multiplied by two is", int(i) * 2)
    else:
        print(s, "multiplied by two is", i * 2)
    break